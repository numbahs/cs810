open Ast

type subst = (string,Ast.texpr) Hashtbl.t

